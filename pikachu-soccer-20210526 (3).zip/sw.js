self.addEventListener('fetch', (event) => {
    console.log('fetch');
  });